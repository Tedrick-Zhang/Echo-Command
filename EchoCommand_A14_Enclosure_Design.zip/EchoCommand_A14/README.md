# Echo Command – Preliminary Enclosure Design
ECE 1895 Assignment 14, **Option B** · Team: Tengyue Zhang, Xiaodong Deng, Chuxuan Zhou
CAD tool: **FreeCAD 1.1** (free). The STEP files also open in Fusion 360, SolidWorks and Onshape.

## Files
| Path | What it is |
|---|---|
| `EchoCommand_Enclosure.FCStd` | Full design: both units, printed parts + reference models of every electronic part |
| `STEP/` | Each printed part, plus the whole assembly with electronics |
| `STL/` | Print-ready meshes of the 5 printed parts |
| `images/` | Screenshots of the design in the CAD environment |
| `source/` | Parametric FreeCAD macro that regenerates everything (change a dimension, re-run) + Adafruit STEP models (MIT licence) |

## Printed parts (PLA, Pitt blue / gold, 2.5 mm walls)
| Unit | Part | Size (mm) | Notes |
|---|---|---|---|
| Handheld controller | Top shell | 162 × 105 × 34 | Push It, START, Flip It, Twist It on top; power rocker on the front edge; engraved labels |
| | Bottom shell | 162 × 105 × 16 (+2 lip) | Feather bosses, LiPo pocket, USB-C opening, counterbored M3 holes |
| | Twist It knob | Ø22 × 15 | 18 grip flutes, pointer, Ø6.0 bore for the 6 mm knurled shaft |
| Command-and-score station | Top shell | 130 × 110 × 70 | 32° display face: OLED window, two 10 mm LEDs, speaker grille; rocker + USB-C notch on the back |
| | Base plate | 130 × 110 × 2.5 | Alignment lip, Feather + perfboard bosses, battery cradle |

Assembled: controller 162 × 105 × 50 mm, station 130 × 110 × 70 mm.

## Cut-outs, sized from the part datasheets
| Part | Opening |
|---|---|
| Push It – 30 mm arcade button (Adafruit 3489) | Ø30.3 |
| START – 24 mm arcade button (Adafruit 3433) | Ø24.2 |
| Flip It – SPDT toggle, 1/4-40 bushing (E-Switch 100SP1T1B1M1QEH) | Ø6.6 |
| Twist It – 10 kΩ pot, M7 bushing (Bourns PDB181-E415K-103B) | Ø7.3 |
| Power rocker (E-Switch RA11131121) | 19.2 × 13.0, wall locally thinned to 1.8 mm for the snap latches |
| USB-C on the ESP32 Feather V2 (Adafruit 5400) | 13.0 × 7.5, centred on the receptacle (position from Adafruit's board file) |
| 10 mm LEDs (Kingbright WP813GD / WP813ID) | Ø10.2 + 9 mm collar, dome sits ~1 mm proud |
| 0.96" OLED (Adafruit 326) | 24 × 12.5 window + pocket frame for the 29.2 × 26.7 PCB |
| Speaker 4 Ω 3 W (Adafruit 3351) | 6 slots 32 × 2.4; 4 bosses on its 64 × 24 hole pattern |

## Changes from the proposal sketch
* Controller is 50 mm tall instead of 40: the 30 mm arcade button reaches ~37 mm below the panel (Adafruit model), plus room for its wires.
* Controller footprint grew to 162 × 105 mm so the 1200 mAh LiPo fits beside the controls.
* Station front edge is 30 mm instead of 25 (same 32° face) so the speaker clears the 2500 mAh LiPo underneath it.

## Hardware
8 × M3 heat-set inserts (Ø4.0 holes) · 4 × M3 × 20 (controller) and 4 × M3 × 10 (station) socket-head screws ·
16 × M2.5 × 6 self-tapping screws (2 Feathers, perfboard, speaker) · double-sided foam tape for the batteries ·
4 stick-on rubber feet for the station (optional).

## Printing
0.2 mm layers, 3 perimeters, 15–20 % infill.
Controller top shell: top face down (no supports; a brim helps the rounded top edge). Controller bottom shell and base plate: flat side down.
Knob: base down. Station top shell: lay it on its back wall – the 32° face and top then print without support; only the front wall needs tree supports.

## Assembly (summary)
1. Press the M3 inserts into the 8 bosses with a soldering iron.
2. Controller: fit the buttons, toggle, pot and rocker to the top shell; screw the Feather to the bottom shell; tape the LiPo into its pocket; wire; close with 4 × M3 × 20 from below; press on the knob.
3. Station: screw the speaker to its bosses, drop the OLED into its frame (hot-glue dots), push the LEDs into their collars, snap in the rocker; mount the Feather and perfboard (DFPlayer) on the base plate and tape the LiPo into the cradle; lower the shell over the base (the USB-C notch slides over the port) and fasten with 4 × M3 × 10.

## Still to confirm on the real parts (preliminary design)
OLED window position against the actual module · rocker snap-in panel thickness · pot anti-rotation tab · final perfboard size (bosses assume a 40 × 60 mm board) · wire routing and strain relief.

## Re-generating the model
Open FreeCAD 1.1 → Macro → Macros… → select `source/EchoCommand_Enclosure.FCMacro` → Execute (keep `reference_models/` next to it). Every dimension is a named parameter at the top of the macro.
